
# KALKULATOR SEDERHANA

Kalkulator adalah sebuah perangkat atau program sederhana yang dirancang untuk melaksanakan operasi aritmatika dasar. Tujuan utama dari kalkulator ini adalah memungkinkan pengguna untuk melakukan berbagai operasi matematika seperti penambahan, pengurangan, perkalian, dan pembagian angka. Dengan antarmuka yang mudah digunakan, pengguna dapat memasukkan angka dan simbol operasi yang diinginkan untuk mendapatkan hasil perhitungan secara instan. Kalkulator menjadi alat yang sangat berguna dalam kehidupan sehari-hari, baik dalam lingkup pendidikan, bisnis, maupun aktivitas pribadi lainnya.

## Authors

- [@aledhita02](https://github.com/aledhita02)


## Features

- Penambahan: Melakukan operasi penambahan dua angka.
- Pengurangan: Melakukan operasi pengurangan dua angka.
- Perkalian: Melakukan operasi perkalian dua angka.
- Pembagian: Melakukan operasi pembagian dua angka.


## Tech Stack

**Tech** : Bootstrap, PHP, Html, css


## Screenshots

![App Screenshot](https://cdn.discordapp.com/attachments/892804875258314772/1134036246633652344/image.png)


## Feedback

Jika ada yang ingin ditanyakan, dapat langsung melakukan feedback ke aledhita@gmail.com



