<!-- Alessandro Pramudhita Putra Setyawan_Universitas Gunadarma -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="Description" content="Enter your description here" />

    <title>Latihan</title>
</head>

<body>
    <?php
    echo "Selamat Datang<br>";
    echo "Ayo kita belajar Junior Web Developer bersama<br>";
    echo "di BPPTIK Cikarang";
    ?>
</body>

</html>